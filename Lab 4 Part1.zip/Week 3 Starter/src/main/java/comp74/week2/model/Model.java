package comp74.week2.model;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public class Model {

    HashMap<Integer, Profile> profiles;
    HashMap<Integer, Posting> postings;
    HashMap<String, Profile> userMap;

    private static Integer nextProfileId = 100;
    private static Integer nextPostingId = 100;

    public Model() {
        super();
        profiles = new HashMap<>();
        userMap = new HashMap<>();
        postings = new HashMap<>();
    }

    // POST
    public Posting addPosting(Profile profile, Posting posting) { //peofile that is gonna create posting and posting itself
        posting.setPostingId(nextPostingId++); //auto increment posting id
        posting.setDate(LocalDateTime.now());
        posting.setUserName(profile.getUserName()); //set the username of posting
        postings.put(posting.getPostingId(), posting); //then we add posting to collection of postings
        profile.addPosting(posting);
        return posting;
    }

    public Profile addProfile(Profile profile) { //public ResponseEntity<Profile> addProfile(Profile profile)
        Profile newProfile = null;
        if (userMap.get(profile.getUserName()) == null) { //if we get null, - username is new
            newProfile = profile;
            newProfile.setProfileId(nextProfileId++);
            profiles.put(newProfile.getProfileId(), newProfile); //we add profile to collection of profiles
            userMap.put(newProfile.getUserName(), newProfile);
        }
        return newProfile;  //return new ResponseEntity<>(newProfile, HttpStatus.CREATED);
    }

    // GET ALL

    public List<Profile> getProfiles() {
        return new ArrayList<>(profiles.values());
    }

    public List<Posting> getPostings() {
        return new ArrayList<>(postings.values());
    }

    // GET BY ???

    public Profile getProfileById(Integer id) {
        Profile profile = profiles.get(id);
        return profile;
    }

    public List<Profile> getProfilesByUserName(String userName) {
        Profile profile = userMap.get(userName);
        return new ArrayList<>(Arrays.asList(profile));
    }

    public Profile getProfileByUserName(String userName) {
        Profile profile = userMap.get(userName);
        return profile;
    }

    //PUT 
    public Posting updatePosting(Profile profile, Integer postingId, Posting posting) {
        Posting newPosting = null;
        if (postings.get(postingId) != null) { //checks if posting exists
            newPosting = posting; //newPosting is the posting that we get from the request
            newPosting.setPostingId(postingId); //set posting id
            newPosting.setDate(LocalDateTime.now()); //set date
            newPosting.setUserName(profile.getUserName()); //set username
            postings.put(postingId, newPosting); //add posting to collection of postings
        }
        return newPosting; //return new ResponseEntity<>(newPosting, HttpStatus.OK);
    }

    public Posting deletePosting(Profile profile, Integer postingId) {
        Posting posting = postings.get(postingId);
        if (posting != null) {
            postings.remove(postingId);
            profile.removePosting(posting);
        }
        return posting;
    }

    public List<Posting> deletePostings(Profile profile) {
        List<Posting> postings = profile.getPostings();
        for (Posting posting : postings) {
            this.postings.remove(posting.getPostingId());
        }
        profile.setPostings(new ArrayList<>());
        return postings;
    }

    public void deleteProfile(Profile profile) {
        // TODO Auto-generated method stub
        throw new UnsupportedOperationException("Unimplemented method 'deleteProfile'");
    }
}
